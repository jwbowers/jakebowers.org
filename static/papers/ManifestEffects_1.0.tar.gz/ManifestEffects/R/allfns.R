
rose.covadj.fn<-function(h,dist=approximate(B=5000),fmla,data){
  require(RItools);require(coin)
  ##First, make residuals
  thelm<-lm(fmla,data=data)##;print(coef(thelm)) 
  thee<-resid(thelm)
  
  ##Next do some tests on those residuals
  ###First, the signed rank test:
  thewt<-wilcox_test(thee~factor(z)|factor(sF),data=data,distribution=dist)
  thep.w<-pvalue(thewt)[1]
  
  ###Second, difference of means relying on asymptotics
  thexbal.2<-xBalance(z~thee,strata=list(block=~sF),data=data,report="chisquare.test")
  thep.xb<-thexbal.2$overall$p.value
  
  ###Third, difference of means sampling from the randomization distribution implied by the null and by the design
  theow<-oneway_test(thee~factor(z)|factor(sF),data=data,distribution=dist)
  thep.ow<-pvalue(theow)[1]
  
  c(p.w=thep.w,p.xb=thep.xb,p.ow=thep.ow,h=h)
}

get.ci.from.p<-function(p,h){
  the95<-range(h[p>=.05])
  the66<-range(h[p>=.33])
  results<-sort(c(the95,the66))
  names(results)<-c("l95","l66","u66","u95")
  results
}


balstats.fn<-function(thecov){
  require(coin)
  
  approx.mean.test<-oneway_test(formula(paste(thecov,"~zF|sF")),data=bignews.df,distribution=approximate(B=1000))
  thealignedcov<-paste(thecov,"Med",sep="")
  exact.ks.test<-try(ks.test(bignews.df[bignews.df$z==1,thealignedcov],
                             bignews.df[bignews.df$z==0,thealignedcov],exact=TRUE))
  approx.wc.test<-wilcox_test(formula(paste(thecov,"~zF|sF")),data=bignews.df,
                              distribution=approximate(B=1000))

  c(##approx.z=statistic(approx.mean.test),
    approx.p=pvalue(approx.mean.test)[1],
    exact.ks.p=if(class(exact.ks.test)=="try-error"){NA}else{exact.ks.test$p.value},
    approx.wc.test=pvalue(approx.wc.test)[1]
    )
  
}



estVe<-function(e,n,N){
  ##Finite pop variance within strata.
  ##n=num ctrls
  ##N=pop size
  fpc<-(1-(n/N)) ##this represents cov(Z_i,Z_j) where Z is assignment--- Lohr \S 2.7
  estvar<- fpc*var(e)/n ##fpc*(sum((e-mean(e))^2)/(n-1))/n ##same as fpc*var(yc)/n
  return(estvar)
}

estVeB<-function(vecofvs,B){
  (1/B)^2*sum(vecofvs)
}



comparesimp.to.pair.xb.fn<-function(df,thearray){
  c(simpsd.vs.pairsd=summary(thearray[df,"xb.simp.sd",]-thearray[df,"xb.pair.sd",]),
    simpsd.to.pairsd.ratio=summary(thearray[df,"xb.simp.sd",]/thearray[df,"xb.pair.sd",]),
    numsimplesspair=sum((thearray[df,"xb.simp.sd",]/thearray[df,"xb.pair.sd",])<1),
    propsimplesspair=sum((thearray[df,"xb.simp.sd",]/thearray[df,"xb.pair.sd",])<1)/dim(thearray)[3],
    meancovsimp95=mean(abs(thearray[df,"xb.simp.z",])>qnorm(.975)),
    meancovsimp90=mean(abs(thearray[df,"xb.simp.z",])>qnorm(.95)),
    meancovpair95=mean(abs(thearray[df,"xb.pair.z",])>qnorm(.975)),
    meancovpair90=mean(abs(thearray[df,"xb.pair.z",])>qnorm(.95))
    )
}

comparesimp.to.pair.lm.fn<-function(df,thearray){ ##using T here rather than Z to go along with lm assumptions
  thedat<-get(df)
  n<-nrow(thedat)
  k<-length(unique(thedat$p))
  c(simpsd.vs.pairsd=summary(results[df,"lm.simp.sd",]-results[df,"lm.pair.sd",]),
    t.meancovsimp95=mean(abs(results[df,"lm.simp.t",])>qt(.975,df=n-k-1)),
    t.meancovsimp90=mean(abs(results[df,"lm.simp.t",])>qt(.95,df=n-k-1)),
    t.meancovpair95=mean(abs(results[df,"lm.pair.t",])>qt(.975,df=n-k-1)),
    t.meancovpair90=mean(abs(results[df,"lm.pair.t",])>qt(.95,df=n-k-1)),
    n.meancovsimp95=mean(abs(results[df,"lm.simp.t",])>qnorm(.975)), ##but look at normal too
    n.meancovsimp90=mean(abs(results[df,"lm.simp.t",])>qnorm(.95)),
    n.meancovpair95=mean(abs(results[df,"lm.pair.t",])>qnorm(.975)),
    n.meancovpair90=mean(abs(results[df,"lm.pair.t",])>qnorm(.95))
    )
}


fnbyblock<-function (x, block, fn) {
  unsplit(lapply(split(x, block), function(x) {
    fn(x)
  }), block)
}


alignbyblock<-function(x,block,fn=mean){
  ##"aligns" values of a variable within blocks/strata/sets.
  ##Default is to subtract off the mean.
  unsplit(lapply(split(x,block),function(x){x-fn(x)}),block)
}



makedat.pairs<-function(thedf,resp,trt,strat){
  ##draws generates random normal draws centered on means of control
  ##obs within strata, with variance equal to variance within strata.
  
 
  ##this is a kind of bootstrap procedure (sampling within strata with
  ##replacement).  assumes equal sized strata for now
  
  z<-thedf[,trt]
  s<-thedf[,strat]
  r<-thedf[,resp] ##observed outcome

  ##First create control obs/baseline covs that differ determininstically by pair: simulating pairs well-chosen with some variable with finite variance
  
  ##Use the kind of variation in baseline turnout found in the Panagopoulos dataset (12 to 48) to anchor bottom, rounded to 10 but allow up to 60
    ##themeans<-tapply(r[z==0],s[z==0],mean) ##same as r[z==0];names(themeans)<-unique(s), try means which differ in a particular patter rather than based on Costas' data.
  ##r.baseline<-seq(10,60,length.out=length(unique(s)))
  r.baseline<-tapply(r[z==0],s[z==0],mean)
  names(r.baseline)<-sort(unique(s))
  inter.pair.width<-mean(diff(r.baseline))
  

  nb<-unique(tapply(z,s,length))
  stopifnot(length(nb)==1) ##all strata must be same size
  stopifnot(unique(table(s))==nb) ##only for pairs for now

  ##Using the original data
  ##thesds<-tapply(r,s,sd) ##try to make pairs relatively homogenous (compare later to pairmatch())
  ##large sds make for many draws where pairs are more heterogeneous 
 
  ##make the within pair sds pretty tight, but need to be adjusted for number of pairs since the baseline value range doesn't change as pairs increase: situation is like choosing pairs from some population and getting ever more pairs from same population.
  origsds<-tapply(r,s,sd)
  ##thesds<-seq(1,min(inter.pair.width/2,mean(origsds)/2),length.out=length(z))
  ##if draw from normal need to truncate somehow
  ##thesds<-rnorm(length(unique(s)),mean=mean(origsds),sd(origsds))
  
  ##Draw from sd=min(origsds) to upper limite at median of Panagopoulos data --- basically try to prevent overly heterogeneous pairs, but also avoid too unrealistically homogeneous ones, too
  ##thesds<-runif(length(unique(s)),min=min(origsds),max=median(origsds)) ##the original range 
  thesds<-origsds

  boot.samp.r<-as.vector(sapply(unique(s),function(x){
    rnorm(2,mean=r.baseline[x],sd=thesds[x])  ##using Normal draws within pairs for now. 
  }))
  
  thedf[,resp]<-boot.samp.r

  ##thedf[,trt]<-unlist(tapply(z,s,sample,replace=FALSE))##shuffles z 

  return(thedf)
}


##library(optmatch)
sdiffs<-function(treatments,controls){
  abs(outer(treatments$r,controls$r,`-`)) ##use r because drawn to reflect control group
}


makecovadjplot<-function(outcome,covariate,treatment,data,xlab,ylab){
  thecov<-data[,covariate]
  theout<-data[,outcome]
  z<-data[,treatment]

  lmR0<-lm(theout~z)
  lmR1<-lm(theout~z+thecov)
  
  plot(thecov,theout,
       ylim=range(theout),
       col=c("black",gray(.5))[z+1],pch=19,cex=1,
       xlab=xlab,ylab=ylab)
  
  curve(coef(lmR1)[1]+coef(lmR1)["z"]*1+coef(lmR1)["thecov"]*x,from=min(thecov),to=max(thecov),col=gray(.5),add=TRUE,lwd=2)
  curve(coef(lmR1)[1]+coef(lmR1)["z"]*0+coef(lmR1)["thecov"]*x,from=min(thecov),to=max(thecov),col="black",add=TRUE,lwd=2)

  xmean<-mean(thecov)
  
  segments(xmean,par("usr")[3],xmean,par("usr")[4],col="gray")
  unadjmeans<-tapply(theout,z,mean)
  baseline.means<-tapply(thecov, z,mean)
  points(baseline.means,unadjmeans,col=c("black",gray(.5)),pch=0,lwd=2) ##perhaps use text instead?
  
  adjmeans<-coef(lmR1)[1]+coef(lmR1)["z"]*c(0,1)+coef(lmR1)["thecov"]*mean(thecov) 
  points(c(xmean,xmean),adjmeans,col=c("black",gray(.5)),pch=22,lwd=2)

  espx<-diff(par("xaxp")[1:2])/10
  espy<-diff(par("yaxp")[1:2])/10

  arrows(baseline.means[1],unadjmeans[1]+espy/4,par("xaxp")[1]+espx,par("yaxp")[2]-espy/4,length=.07,angle=30,code=1)
  arrows(baseline.means[2],unadjmeans[2]+espy/4,par("xaxp")[1]+espx,par("yaxp")[2]-espy/4,length=.07,angle=30,code=1)
  text(par("xaxp")[1]+espx,par("yaxp")[2]-espy/4,"Unadj. Means",cex=.8,pos=1,offset=-.25)
  
  arrows(xmean,adjmeans[1]+espy/4,par("xaxp")[2]-espx,par("yaxp")[2]-espy/4,length=.07,angle=30,code=1)
  arrows(xmean,adjmeans[2]+espy/4,par("xaxp")[2]-espx,par("yaxp")[2]-espy/4,length=.07,angle=30,code=1)
  text(par("xaxp")[2]-espx,par("yaxp")[2]-espy/4,"Adj. Means",cex=.8,pos=1,offset=-.25)
  
  segments(baseline.means[1],unadjmeans[1],par("usr")[1],unadjmeans[1],lwd=1,lty=2,col="black")
  segments(baseline.means[2],unadjmeans[2],par("usr")[1],unadjmeans[2],lwd=1,lty=2,col=gray(.5))
  
  segments(xmean,adjmeans[1],par("usr")[1],adjmeans[1],lwd=1,lty=1,col="black")
  segments(xmean,adjmeans[2],par("usr")[1],adjmeans[2],lwd=1,lty=1,col=gray(.5))

  arrows(par("xaxp")[1]+espx/2,unadjmeans[1],par("xaxp")[1]+espx/2,unadjmeans[2],lwd=1,code=3,length=.05,angle=30,lty=2,col="gray")
  text(par("xaxp")[1]+espx/2,mean(unadjmeans),round(diff(unadjmeans),1),cex=.9,font=2)##,pos=2)
 
  arrows(par("xaxp")[1]+1.5*espx,adjmeans[1],par("xaxp")[1]+1.5*espx,adjmeans[2],lwd=1,code=3,length=.05,angle=30,col="gray")
  text(par("xaxp")[1]+1.5*espx,mean(adjmeans),round(diff(adjmeans),1),cex=.9,font=2)##,pos=4)
    
}
